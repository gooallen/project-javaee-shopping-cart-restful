package com.algonquincollege.cst8277.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2019-04-05T03:31:36.172+0000")
@StaticMetamodel(ModelBase.class)
public class ModelBase_ {
	public static volatile SingularAttribute<ModelBase, Integer> id;
	public static volatile SingularAttribute<ModelBase, Integer> version;
	public static volatile SingularAttribute<ModelBase, Audit> audit;
}
